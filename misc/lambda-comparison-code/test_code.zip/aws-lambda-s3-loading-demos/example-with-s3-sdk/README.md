this is a sample using the aws s3 sdk. modify the resource file to access your own bucket
use mvn package to create aws lambda jarfile
