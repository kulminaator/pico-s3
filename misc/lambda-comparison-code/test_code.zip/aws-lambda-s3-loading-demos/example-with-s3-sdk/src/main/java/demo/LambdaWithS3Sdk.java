package demo;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.EnvironmentVariableCredentialsProvider;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class LambdaWithS3Sdk implements RequestHandler<String, String> {

    private long loaded = System.currentTimeMillis();
    private boolean isFirstTime = true;

    @Override
    public String handleRequest(String ignored, Context context) {
        String s3BucketName = this.getS3BucketName();
        long start = System.currentTimeMillis();
        String s3ReadResult = this.doS3Read(s3BucketName);
        long end = System.currentTimeMillis();
        final String result = String.format("%s read from S3 '%s' in %d ms (%d ms since class load), " +
                        "first time since cold boot: %s\n",
                this.getClass(),
                s3ReadResult,
                end-start,
                end-this.loaded,
                String.valueOf(isFirstTime));
        System.out.println(result);
        isFirstTime = false;
        return result;
    }

    private String getS3BucketName() {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("s3_config.properties");
        Properties s3Config = new Properties();
        try {
            s3Config.load(inputStream);
        } catch (IOException e) {
            throw new RuntimeException("Can't load resource s3_config.properties, make sure you added it");
        }
        return s3Config.getProperty("bucket_name");
    }

    private String doS3Read(String bucketName) {
        AWSCredentialsProvider credentials = new EnvironmentVariableCredentialsProvider();
        AmazonS3 client = AmazonS3ClientBuilder.standard().withCredentials(credentials).build();
        return client.getObjectAsString(bucketName, "hello_world.txt");
    }
}
