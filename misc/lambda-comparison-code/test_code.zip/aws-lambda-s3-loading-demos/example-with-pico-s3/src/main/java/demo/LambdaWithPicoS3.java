package demo;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.github.kulminaator.s3.Client;
import com.github.kulminaator.s3.PicoClient;
import com.github.kulminaator.s3.auth.CredentialsProvider;
import com.github.kulminaator.s3.auth.EnvironmentCredentialsProvider;
import com.github.kulminaator.s3.http.PicoHttpClient;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class LambdaWithPicoS3 implements RequestHandler<String, String> {

    private long loaded = System.currentTimeMillis();
    private boolean isFirstTime = true;

    @Override
    public String handleRequest(String ignored, Context context) {
        String s3BucketName = this.getS3BucketName();
        long start = System.currentTimeMillis();
        String s3ReadResult = this.doS3Read(s3BucketName);
        long end = System.currentTimeMillis();
        final String result = String.format("%s read from S3 '%s' in %d ms (%d ms since class load), " +
                        "first time since cold boot: %s\n",
                this.getClass(),
                s3ReadResult,
                end-start,
                end-this.loaded,
                String.valueOf(isFirstTime));
        System.out.println(result);
        isFirstTime = false;
        return result;
    }

    private String getS3BucketName() {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("s3_config.properties");
        Properties s3Config = new Properties();
        try {
            s3Config.load(inputStream);
        } catch (IOException e) {
            throw new RuntimeException("Can't load resource s3_config.properties, make sure you added it");
        }
        return s3Config.getProperty("bucket_name");
    }

    private String doS3Read(String bucketname) {
        CredentialsProvider envCredentialsProvider = new EnvironmentCredentialsProvider();
        final Client pClient = new PicoClient.Builder()
                .withHttpClient(new PicoHttpClient())
                .withCredentialsProvider(envCredentialsProvider)
                .withRegion("eu-west-1")
                .build();
        try {
            return pClient.getObjectDataAsString(bucketname, "hello_world.txt");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
