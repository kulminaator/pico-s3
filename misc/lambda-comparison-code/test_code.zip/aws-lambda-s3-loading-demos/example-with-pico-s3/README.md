this is a sample using the pico s3 library. modify the resource file to access your own bucket
use mvn package to create aws lambda jarfile
